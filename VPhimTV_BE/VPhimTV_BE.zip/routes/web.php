<?php

include_once('web/auth.php');
include_once('web/admin.php');
include_once('web/dashboard.php');