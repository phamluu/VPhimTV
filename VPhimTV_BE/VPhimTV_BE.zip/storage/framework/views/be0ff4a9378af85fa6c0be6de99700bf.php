<?php $__env->startSection('content'); ?>
<div class="panel-header panel-header-sm"></div>
<div class="content">
    <div class="row">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h5 class="title">Thêm quốc gia</h5>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('country.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <?php endif; ?>

                        <div class="form-group">
                            <label for="name">Tên quốc gia</label>
                            <input type="text" name="name" class="form-control" placeholder="Nhập tên quốc gia" value="<?php echo e(old('name')); ?>">
                        </div>

                        <button type="submit" class="btn btn-primary btn-round">Thêm</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\VPhimTV\VPhimTV_BE\resources\views/Country/create.blade.php ENDPATH**/ ?>