<div class="modal fade" id="episode_add" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalLabel">Thêm mới tập phim</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Đóng">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="<?php echo e(route('episode.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="content">
                        <div class="card">
                            <div class="card-body">

                                <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                                <?php endif; ?>
                                <?php if(session('success')): ?>
                                <div class="alert alert-success mt-2">
                                    <?php echo e(session('success')); ?>

                                </div>
                                <?php endif; ?>
                                <?php echo $__env->make('episode._field', ['model' => $model], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary btn-round">Thêm</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Đóng</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $('form').on('submit', function(e) {
            e.preventDefault();

            var form = this;
            var formData = new FormData(form);

            $.ajax({
                url: $(form).attr('action'),
                type: $(form).attr('method'),
                data: formData,
                processData: false,
                contentType: false,
                xhrFields: {
                    withCredentials: true
                },
                success: function(response) {
                    console.log(response);
                    if (response.status === true) {
                        alert('Tải lên thành công!');
                    } else {
                        alert('Đã có lỗi xảy ra: ' + (response.message || 'Vui lòng thử lại.'));
                    }
                },
                error: function(xhr) {
                    if (xhr.status === 419) {
                        alert('CSRF token không hợp lệ hoặc đã hết hạn.');
                    } else {
                        alert('Upload thất bại');
                    }
                }
            });
        });
    })
</script><?php /**PATH C:\wamp64\www\VPhimTV\VPhimTV_BE\resources\views/episode/create.blade.php ENDPATH**/ ?>