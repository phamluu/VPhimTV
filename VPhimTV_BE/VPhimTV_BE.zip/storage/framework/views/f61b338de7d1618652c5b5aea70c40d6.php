<?php $__env->startSection('content'); ?>
<div class="panel-header panel-header-sm"></div>
<div class="content">
    <div class="card">
        <div class="card-header">
            <h5 class="title">Thêm phim mới</h5>
        </div>
    </div>
    <form action="<?php echo e(route('movie.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo $__env->make('movie._field', ['model' => $model], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\VPhimTV\VPhimTV_BE\resources\views/movie/create.blade.php ENDPATH**/ ?>