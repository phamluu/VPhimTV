

<?php $__env->startSection('content'); ?>
<div class="panel-header panel-header-sm"></div>
<div class="content">
    <div class="card">
        <div class="card-header">
            <h5 class="title">Thông tin phim</h5>
        </div>
    </div>
    <div class="row">
        <div class="col-md-8">
            <div class="card">
                <div class="card-body">
                    <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <?php endif; ?>

                    <?php if(session('success')): ?>
                    <div class="alert alert-success mt-2">
                        <?php echo e(session('success')); ?>

                    </div>
                    <?php endif; ?>

                    <div class="form-group">
                        <label for="name">Tên phim</label>
                        <span><?php echo e(old('name', $model->name)); ?></span>
                    </div>
                    <div class="form-group">
                        <label for="original_name">Tên gốc</label>
                        <span><?php echo e(old('original_name', $model->original_name)); ?></span>
                    </div>
                    <div class="form-group">
                        <label for="thumb_url">Thumb URL</label>
                        <?php if($model->thumb_url): ?>
                        <div class="mt-2">
                            <img src="<?php echo e(asset( $model->thumb_url)); ?>" height="100">
                        </div>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="trailer_url">Trailer URL</label>
                        <span><?php echo e(old('trailer_url', $model->trailer_url)); ?></span>
                    </div>

                    <div class="form-group">
                        <label for="poster_url">Poster URL</label>
                        <span><?php echo e(old('poster_url', $model->poster_url)); ?></span>
                    </div>
                    <div class="form-group">
                        <label for="actor">Diễn viên</label>
                        <span><?php echo e(old('actor', $model->actor)); ?></span>
                    </div>

                    <div class="form-group">
                        <label for="director">Đạo diễn</label>
                        <span><?php echo e(old('director', $model->director)); ?></span>
                    </div>
                    <div class="form-group">
                        <label for="content">Nội dung</label>
                        <div><?php echo e(old('content', $model->content)); ?></div>
                    </div>


                    <div class="form-group">
                        <label for="type_id">Thể loại</label>
                        <span><?php echo e($movie_type->name); ?></span>
                    </div>

                    <div class="form-group">
                        <label for="time">Thời lượng</label>
                        <span><?php echo e(old('time', $model->time)); ?></span>
                    </div>

                    <div class="form-group">
                        <label for="episode_current">Tập hiện tại</label>
                        <span><?php echo e(old('episode_current', $model->episode_current)); ?></span>
                    </div>

                    <div class="form-group">
                        <label for="episode_total">Tổng số tập</label>
                        <span><?php echo e(old('episode_total', $model->episode_total)); ?></span>
                    </div>

                    <div class="form-group">
                        <label for="quality">Chất lượng</label>
                        <span><?php echo e(old('quality', $model->quality)); ?></span>
                    </div>

                    <div class="form-group">
                        <label for="language">Ngôn ngữ</label>
                        <span><?php echo e(old('language', $model->language)); ?></span>
                    </div>

                    <div class="form-group">
                        <label for="year">Năm</label>
                        <span><?php echo e(old('year', $model->year)); ?></span>
                    </div>

                    <div class="form-group">
                        <label for="country_id">Quốc gia</label>
                        <span><?php echo e($country->name); ?></span>
                    </div>

                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    <h6>Danh sách tập phim</h4>
                        <a href="#" class="btn primary" data-toggle="modal" data-target="#episode_add">Thêm tập</a>
                        <div class="episode">
                            <?php $__currentLoopData = $episodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span><?php echo e($item -> episode_name); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php

use App\Models\Episode;

$episode = new Episode();
$episode->movie_id = $model->id;
?>
<?php echo $__env->make('episode.create', ['model' => $episode], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\VPhimTV\VPhimTV_BE\resources\views/movie/detail.blade.php ENDPATH**/ ?>